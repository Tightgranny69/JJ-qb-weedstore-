Config = {}

Config.WeedShop = {
    location = vector3(-1604.67, -1027.78, 13.15),
    pedModel = "mp_m_weapexp_01"
}
